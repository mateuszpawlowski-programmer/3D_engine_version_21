//Mateusz Pawlowski. 3D Software Renderer. 2023.

package pkg3d;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;
import javax.swing.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class R_3D extends JPanel implements Runnable,MouseListener,MouseMotionListener,KeyListener,MouseWheelListener {

    /**
     * @param args the command line arguments
     */
        public JPanel panel;
        
        public JFrame frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        ArrayList<Point3d> vertices=new ArrayList<Point3d>();
        
        ArrayList<Point3d> vertices_xyz=new ArrayList<Point3d>();
        
        //ArrayList<Point3d> normals=new ArrayList<Point3d>();
        //ArrayList<Integer> normals_index=new ArrayList<Integer>();
        
        ArrayList<Integer> faces=new ArrayList<Integer>();
                
        JButton b1=new JButton("<");
        JButton b2=new JButton(">");
        JButton b5=new JButton("Play");
        JButton b3=new JButton("^");
        JButton b4=new JButton("v");
        
        JButton b6=new JButton("+");
        JButton b7=new JButton("-");
        
        JButton b8=new JButton("WireFrame");
        JButton b9=new JButton("S");
        
        JButton b10=new JButton("1");
        JButton b11=new JButton("2");
        JButton b12=new JButton("3");
        JButton b13=new JButton("4");
        JButton b14=new JButton("5");
        JButton b23=new JButton("6");
        JButton b24=new JButton("F");
        
        
        JButton b15=new JButton("^^");
        JButton b16=new JButton("vv");
        JButton b17=new JButton("<<");
        JButton b18=new JButton(">>");
        
        JButton b19=new JButton("<");
        JButton b20=new JButton(">");
        JButton b21=new JButton("Up");
        JButton b22=new JButton("Down");
        
        boolean application_running=true;
        
        double cube_angleX=0.4;
        double cube_angleY=0;
        
        int old_mouse_x=0;
        int old_mouse_y=0;
        boolean mouse_pressed=false;
        boolean mouse_2_pressed=false;
        
        boolean play=false;
        
        int move_scale=50;
        
        int scale=0;
        
        static boolean calculate_normals=true;
          
        static boolean draw_demo=false;
        static boolean tomb_raider=false;
        static boolean tea_pot=false;
        static boolean lamborghini=true;
        static boolean q2dm1=false;
        static boolean crash_bandicoot=false;
        static boolean doom=false;
        static boolean quake=false;
        static boolean quake_standard_shading=true;
        
        static boolean tr_map=false;
        
        static boolean wire_frame=false;
        static boolean set_center=false;
        
        static boolean turn_right=false;
        static boolean turn_left=false;
        
        int sc=3;
        
        static int triangle_pointer=0;
        
        static double player_x=0,player_z=0;
                
        Point3d p1=new Point3d(-10*sc,-10*sc,-10*sc);
        Point3d p2=new Point3d(10*sc,-10*sc,-10*sc);
        Point3d p3=new Point3d(-10*sc,10*sc,-10*sc);
        Point3d p4=new Point3d(10*sc,10*sc,-10*sc);
        
        Point3d p5=new Point3d(-10*sc,-10*sc,10*sc);
        Point3d p6=new Point3d(10*sc,-10*sc,10*sc);
        Point3d p7=new Point3d(-10*sc,10*sc,10*sc);
        Point3d p8=new Point3d(10*sc,10*sc,10*sc);
        
        Point3d[] tab=new Point3d[]{p1,p2,p3,p4,p5,p6,p7,p8};
        
        Point3d pn1=new Point3d(0,0,-10);
        Point3d pn2=new Point3d(0,0,10);
        
        Point3d pn3=new Point3d(0,-10,0);
        Point3d pn4=new Point3d(0,10,0);
        
        Point3d pn5=new Point3d(10,0,0);
        Point3d pn6=new Point3d(-10,0,0);
        
        double angle=0;
        Graphics g;
        
        public Thread thread;
        
        
        
        
    
    public R_3D()
    {
                
                //read .obj file with 3d object
                int count_normals=0;
                
                try{
                BufferedReader bfr=null;
                
                if(lamborghini==true){bfr=new BufferedReader(new FileReader("lamborghini.obj"));}
                
                //if(doom==true){bfr=new BufferedReader(new FileReader("E1M1.obj"));}
                
                if(tr_map==false)
                {
                    if(quake==false)
                    {
                        if(doom==true){bfr=new BufferedReader(new FileReader("new_doom.obj"));}
                        //if(doom==true){bfr=new BufferedReader(new FileReader("doom_2.obj"));}
                    }
                    
                    if(quake==true)
                    {
                        if(doom==true){bfr=new BufferedReader(new FileReader("quake.obj"));}
                    }
                }

                if(tr_map==true)
                {
                    if(doom==true){bfr=new BufferedReader(new FileReader("Tomb_Raider_lv1.obj"));}
                }
                
                //if(doom==true){bfr=new BufferedReader(new FileReader("q2dm1.obj"));}
                //if(lamborghini==true){bfr=new BufferedReader(new FileReader("q2dm1.obj"));}
                
                if(tomb_raider==true){bfr=new BufferedReader(new FileReader("tomb_raider.obj"));}
                
                if(crash_bandicoot==true){bfr=new BufferedReader(new FileReader("crash_bandicoot.obj"));}
                
                //if(tomb_raider_2==true){bfr=new BufferedReader(new FileReader("tr_1.obj"));}
                if(tea_pot==true){bfr=new BufferedReader(new FileReader("tea.obj"));}
                
                int count_vertices=0;
                
                int count_faces=0;
                
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        
                        if(tomb_raider==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(lamborghini==true)
                        {
                        
                        vertices.add(new Point3d(vx*40,-vy*40,-vz*40));
                            //if(q2dm1==false) vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                            //else {vertices.add(new Point3d(vx*10,-vz*10,-vy*10));}
                        }
                        
                        if(crash_bandicoot==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(tea_pot==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(doom==true)
                        {
                        if(tr_map==true)
                        {
                        vertices.add(new Point3d(vx*300,-vy*300,-vz*300));
                        }
                        
                        if(tr_map==false)
                        {
                            if(quake==true)
                            {
                                vertices.add(new Point3d(vx*100,-vy*100,-vz*100));
                            }
                            if(quake==false){
                                //vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                                vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                            }
                        }
                        Point3d pcenter_1=new Point3d(0,0,0);
                        Point3d pcenter_2=new Point3d(150*10,0,0);
                        Point3d pcenter_3=new Point3d(0,-150*10,0);
                        Point3d pcenter_4=new Point3d(0,0,150*10);
                        
                        vertices_xyz.add(pcenter_1);
                        vertices_xyz.add(pcenter_2);
                        vertices_xyz.add(pcenter_3);
                        vertices_xyz.add(pcenter_4);
                        }
                        
                        count_vertices++;
                        
                        }
                        
                        //osobny fragment dla lamborghini
                         
                         //System.out.println(linia);
                         if(lamborghini==true||tea_pot==true||doom==true)
                         {
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);
                                
                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");
                                
                                String t4=null;
                                try{
                                    t4=st.nextToken(" ");
                                }catch(Exception exc){}



                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                
                                StringTokenizer st_2=new StringTokenizer(t2);
                                String ll=st_2.nextToken("//");
                                
                                StringTokenizer st_3=new StringTokenizer(t3);
                                String lll=st_3.nextToken("//");
                                
                                //System.out.println(""+t4);
                                
                                if(t4==null)
                                {
                                //System.out.println(" "+l+" "+ll+" "+lll);
                                }
                                
                                
                                String llll="";
                                if(t4!=null)
                                {
                                StringTokenizer st_4=new StringTokenizer(t4);
                                llll=st_4.nextToken("//");
                                //System.out.println(" "+l+" "+ll+" "+lll+" "+llll);
                                }
                                
                                
                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(ll);
                                int t_3=Integer.parseInt(lll);

                                Integer t_4=null;
                                if(t4!=null)
                                {
                                t_4=Integer.parseInt(llll);
                                }


                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);
                                
                                if(t4!=null)
                                {
                                faces.add(t_4);
                                } else {faces.add(null);}
                                count_faces++;
                                }
                         }       
                         //osobny fragment dla lamborghini
                        
                        if(lamborghini==false&&tea_pot==false&&doom==false){
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");





                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                String ll=st_1.nextToken("//");
                                if(crash_bandicoot==true) ll=st_1.nextToken("//");

                                StringTokenizer st_2=new StringTokenizer(t2);
                                String l2=st_2.nextToken("//");
                                String ll2=st_2.nextToken("//");
                                if(crash_bandicoot==true) ll2=st_2.nextToken("//");

                                StringTokenizer st_3=new StringTokenizer(t3);
                                String l3=st_3.nextToken("//");
                                String ll3=st_3.nextToken("//");
                                if(crash_bandicoot==true) ll3=st_3.nextToken("//");

                                String l4="";
                                String t4="";
                                String ll4="";

                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                StringTokenizer st_4=new StringTokenizer(t4);
                                l4=st_4.nextToken("//"); 
                                ll4=st_4.nextToken("//");
                                }
                        
                                //System.out.println(t1+" "+t2+" "+t3+" "+t4+" ");

                                //System.out.println(l+" "+l2+" "+l3+" "+l4);

                                //System.out.println(ll+" "+ll2+" "+ll3+" "+ll4);

                                int normal_ind=Integer.parseInt(ll);
                                //normals_index.add(normal_ind);

                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(l2);
                                int t_3=Integer.parseInt(l3);




                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);

                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces.add(t_4);
                                    }
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                
                //System.exit(1);
                
                for(Point3d p:vertices)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                    //p.moveVectorOriginal(-200,20,0);
                    
                    if(lamborghini==true){p.moveVectorOriginal(-300,0,0);}
                    //dla doom
                    
                    //player start position
                    //player_x=9300 player_z=-33000
                    //if(doom==true){p.moveVectorOriginal(0,-3000,0);}
                    if(tr_map==false){
                        if(doom==true)
                        {
                            if(quake==false)
                            {
                            p.moveVectorOriginal(9300+900,-2100,-33000+600);this.cube_angleY=90;
                            }
                            
                            if(quake==true)
                            {
                                p.moveVectorOriginal(-2650,-1900,-1500);
                            }
                            //this.cube_angleY=270;
                        }
                    }
                    if(tr_map==true)
                    {
                        //player_x=22351.577565500153 player_z=-33412.39124283574
                        if(doom==true){p.moveVectorOriginal(-12600,-3100,1100);this.cube_angleY=180;}
                    }
                    
                    //dla q2dm1
                    //if(lamborghini==true){p.moveVectorOriginal(300,0,0);}
                    
                    //if(tomb_raider==true){p.moveVectorOriginal(0,400,300);}
                    //if(crash_bandicoot==true){p.moveVector(0,0,0);}
                }
                        
                if(doom==true){
                        for(Point3d p:vertices_xyz)
                        {
                            
                            p.rotateAxisY(0);
                            p.rotateAxisX(0);
                            //p.moveVectorOriginal(-200,20,0);

                            //player start position
                            //player_x=9300 player_z=-33000
                            if(doom==true){p.moveVectorOriginal(0,-2100,0);}
                            if(tr_map==true){p.moveVectorOriginal(-2600,-2100,1500);}
                            //if(doom==true){p.moveVectorOriginal(0,-2100,0);}
                            //if(doom==true){p.moveVectorOriginal(9300,-2100,-33000);}
                        }
                }
                
    this.add(b1);
    this.add(b2);
    this.add(b5);
    this.add(b3);
    this.add(b4);
    
    
    this.add(b6);
    this.add(b7);
    
    this.add(b8);
    this.add(b9);
    
    this.add(b10);
    this.add(b11);
    this.add(b12);
    
    
    
    if(doom==false)
    {
    this.add(b13);
    this.add(b14);
    this.add(b23);
    this.add(b24);
    }
    
    if(doom==true)
    {
    this.add(b13);
    this.add(b14);
    
    this.add(b15);
    this.add(b16);
    this.add(b17);
    this.add(b18);
    this.add(b19);
    this.add(b20);
    this.add(b21);
    this.add(b22);
    
    this.add(b23);
    
    this.add(b24);
    }
    
    b1.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateLeft();
        }
    
    });
    
    b2.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateRight();
        }
    
    });
    
    b3.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateUp();
        }
    
    });
    
    b4.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateDown();
        }
    
    });
    
    b5.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        play();
        }
    
    });
    
    
    b6.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale-100;
        }
    
    });
    
    b7.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale+100;
        }
    
    });
    
    b8.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=true;
        }
    
    });
    
    b9.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=false;
        }
    
    });
    
    b10.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=true;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();
        }
    
    });
    
    b11.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=true;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();    
        }
    
    });
    
    b12.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=true;
        tomb_raider=false;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();        
        }
    
    });
    
    b13.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=true;
        doom=false;
        tr_map=false;
        reload_application();        
        }
    
    });
    
    b14.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        tr_map=false;
        doom=true;
        
        if(quake==true) quake=false; else quake=true;
        
        calculate_normals=false;
        reload_application();        
        }
    
    });
    
    b23.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        doom=true;
        tr_map=true;
        reload_application();    
        }
    });
    
    
    //sterownie dla doom
    b15.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        
        System.out.println("^^");
        
        go_forward();
        }
    });
    
    b16.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        
        System.out.println("vv");
        
        go_backward();
        }
    });
     
     
    b17.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        System.out.println("<<");
        
        strafe_Left();
        }
    });
    
    b18.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        System.out.println(">>");
        
        strafe_Right();
        }
    });
    
    b21.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        up();
        }
    });
    
    b22.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        down();
        }
    });
    
    b24.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        if(calculate_normals==true) calculate_normals=false; else calculate_normals=true;
        }
    });
    
    this.addMouseMotionListener(this);
    this.addMouseListener(this);
    this.addKeyListener(this);
    this.addMouseWheelListener(this);
    
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    }
    

    public void keyPressed(KeyEvent e) {
    //System.out.println("keyPressed"+e.getKeyCode());
    
    if(e.getKeyCode()==87){go_forward();}
    if(e.getKeyCode()==83){go_backward();}
    if(e.getKeyCode()==65){strafe_Left();}
    if(e.getKeyCode()==68){strafe_Right();}
    }
    
     @Override
    public void keyTyped(KeyEvent ke) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
     public void mousePressed(MouseEvent e)
     {
         if(e.getButton()==1){mouse_pressed=true;}
         if(e.getButton()==3){mouse_2_pressed=true;}
          
     }
     
      @Override
    public void mouseReleased(MouseEvent me) {
        mouse_pressed=false;
        mouse_2_pressed=false;
    }
     
     public void mouseMoved(MouseEvent e) {
        //eventOutput("Mouse moved", e);
        
        //System.out.println(""+cube_angleY);
        try{
                    if(doom==true)
                    {
                        turn_left=false;
                        turn_right=false;
                        
                        if(e.getX()>old_mouse_x)
                        {
                        this.cube_angleY=this.cube_angleY-1;
                        }

                        if(e.getX()<old_mouse_x)
                        {
                        this.cube_angleY=this.cube_angleY+1;
                        }

                        if(e.getY()>old_mouse_y)
                        {
                        this.cube_angleX=this.cube_angleX-1;
                        }

                        if(e.getY()<old_mouse_y)
                        {
                        this.cube_angleX=this.cube_angleX+1;
                        }
                        
                        if(e.getX()>480)
                        {
                        //this.cube_angleY=this.cube_angleY-1;
                        turn_right=true;
                        }

                        if(e.getX()<160)
                        {
                        //this.cube_angleY=this.cube_angleY+1;
                        turn_left=true;
                        }
                           this.old_mouse_x=e.getX();
                        this.old_mouse_y=e.getY();  
                        //System.out.println(e.getX());
                        
                    }
        }catch(Exception exc){}
    }
     
    public void mouseDragged(MouseEvent e) {
        //eventOutput("Mouse dragged", e);
    }
    
    
    public void up()
    {
        //System.out.println("Up");
        for(Point3d p:vertices)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
    }
    
    public void down()
    {
        //System.out.println("Down");
        for(Point3d p:vertices)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
    }
    
    public void go_forward()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        
        //move_scale 100
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x+move_x;
        R_3D.player_z=R_3D.player_z+move_y;
        
        for(Point3d p:vertices)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
    }
    
    public void go_backward()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x+move_x;
        R_3D.player_z=R_3D.player_z+move_y;
        
        for(Point3d p:vertices)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        }    
        
    }
    
    public void strafe_Left()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        double alpha = this.cube_angleY * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x+move_x;
        R_3D.player_z=R_3D.player_z+move_y;
        
        for(Point3d p:vertices)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
    }
    
    public void strafe_Right()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        double alpha = this.cube_angleY * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x+move_x;
        R_3D.player_z=R_3D.player_z+move_y;
        
        for(Point3d p:vertices)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
    }
    
    public void reload_application()
    {
        this.application_running=false;
        this.frame.dispose();
                
        R_3D r=new R_3D();
        
        r.panel = r;
        
        r.frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        r.thread=new Thread(r);
        r.thread.start();
        
        r.frame.getContentPane().add(r.panel);
        r.frame.setLocation(500, 300);
        r.frame.pack();
        r.frame.show();
        
        if(tomb_raider==true){ r.scale=r.scale+300;}
        
        if(doom==false)
        {
        r.rotateDown();
        r.rotateDown();
        r.rotateDown();
        }
        
        if(play==true) r.play=true;
        
        
    }
    
    public void play()
    {
    this.play=true;
    }
    
    public void stop()
    {
    this.play=false;
    }
    
    public void rotateLeft()
    {
    stop();
    this.cube_angleY=this.cube_angleY+5;
    System.out.println("cube_angleY"+this.cube_angleY);
    //if (this.cube_angleY>=360){this.cube_angleY=0;}
    //if (this.cube_angleY==0){this.cube_angleY=360-this.cube_angleY;}
    }
    
    public void rotateRight()
    {
    stop();
    this.cube_angleY=this.cube_angleY-5;
    System.out.println("cube_angleY"+this.cube_angleY);
    }
    
    public void rotateUp()
    {
    stop();
    this.cube_angleX=this.cube_angleX-5;
    }
    
    public void rotateDown()
    {
    stop();
    this.cube_angleX=this.cube_angleX+5;
    }
    
    public void run()
    {
        
        while(application_running){
            try{
            
                if(quake==true){Thread.sleep(1);}
                if(quake==false){Thread.sleep(10);}
                
            }catch(InterruptedException exc){return;}
           
            //angle=this.cube_angle;
            //if (angle>=360){angle=0;} else angle=angle+1;
            if(this.play==true)
            {
            //cube_angleX++;
            //cube_angleY++;
            if(cube_angleY>=360){cube_angleY=0;}
            cube_angleY=cube_angleY+1;
            if(tea_pot==true) cube_angleX++;
            //cube_angleX=cube_angleX+1;
            }
            
            double a=angle; 
       
            if(doom==true)
            {
                        if(turn_right==true){
                        this.cube_angleY=this.cube_angleY-1;
                        }
                        if(turn_left==true){
                        this.cube_angleY=this.cube_angleY+1;
                        }
                        if(mouse_pressed==true) go_forward();
                        if(mouse_2_pressed==true) go_backward();
            }
            for(Point3d p:tab)
            {
                
                p.rotateAxisY(cube_angleY);
                p.rotateAxisX(cube_angleX);
                p.calculate2dpoint();
            }

            pn1.rotateAxisY(cube_angleY);
            pn1.rotateAxisX(cube_angleX);
            
            pn2.rotateAxisY(cube_angleY);
            pn2.rotateAxisX(cube_angleX);
            
            pn3.rotateAxisY(cube_angleY);
            pn3.rotateAxisX(cube_angleX);
        
            pn4.rotateAxisY(cube_angleY);
            pn4.rotateAxisX(cube_angleX);
    
            pn5.rotateAxisY(cube_angleY);
            pn5.rotateAxisX(cube_angleX);
            
            pn6.rotateAxisY(cube_angleY);
            pn6.rotateAxisX(cube_angleX);
    
            
            for(Point3d p:vertices)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            
            if(lamborghini==true){p.moveVector(50,50,0+scale);}
            
            //doom
            if(quake==false){
                
                
                if(doom==true)
                {
                    if(tr_map==false){
                    p.moveVector(-500,2550,0+scale);
                    }
                    if(tr_map==true){
                    p.moveVector(0,2550,0+scale);
                    }
                }
                
            }
            
            if(quake==true){
                if(doom==true){p.moveVector(0,2550,0+scale-400);}
            }
            
            //q2dm1
            //if(lamborghini==true){p.moveVector(0,0,5000+scale);}
            
            if(crash_bandicoot==true){p.moveVector(350,800,2000+scale);}
            if(tomb_raider==true){p.moveVector(100,350,450+scale);}
            
            if(tea_pot==true){p.moveVector(150,200,1200+scale);}
            
            p.calculate2dpoint();
            }
            
            for(Point3d p:vertices_xyz)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            
            //doom
            
            if(tr_map==false){
                if(doom==true){p.moveVector(-500,2550,0+scale);}
            }
            
            if(tr_map==true){
                //if(doom==true){p.moveVector(-500-2600,2550,0+scale);}
                //p.moveVector(-500+12600,2550,0+scale);
            }
            
            p.calculate2dpoint();
            }
            
            this.repaint();
        }
        
    }
      public void paintComponent(Graphics g){
        
	super.paintComponent(g);
     
        g.setColor(Color.white);
        
        
        if(quake==true){
        g.setColor(Color.white);
        //g.setColor(new Color(0,0,255));
        }
        
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        
        this.g=g;
        
        
        //draw demo
        if(draw_demo==true){
        /*
        line(p1.x2d, p1.y2d, p2.x2d, p2.y2d);
        line(p1.x2d, p1.y2d, p3.x2d, p3.y2d);
        line(p3.x2d, p3.y2d, p4.x2d, p4.y2d);
        line(p2.x2d, p2.y2d, p4.x2d, p4.y2d);
        
        line(p5.x2d, p5.y2d, p6.x2d, p6.y2d);
        line(p5.x2d, p5.y2d, p7.x2d, p7.y2d);
        line(p7.x2d, p7.y2d, p8.x2d, p8.y2d);
        line(p6.x2d, p6.y2d, p8.x2d, p8.y2d);
        
        line(p1.x2d, p1.y2d, p5.x2d, p5.y2d);
        line(p2.x2d, p2.y2d, p6.x2d, p6.y2d);
        line(p3.x2d, p3.y2d, p7.x2d, p7.y2d);
        line(p4.x2d, p4.y2d, p8.x2d, p8.y2d);
        */
        
        Vect vo=new Vect(0,0,-1);
        
        //Vect v1=new Vect(p1.xr2-p2.xr2,p1.yr2-p2.yr2,p1.zr2-p2.zr2);
        //Vect v2=new Vect(p2.xr2-p4.xr2,p2.yr2-p4.yr2,p2.zr2-p4.zr2);
        
        //Vect v2n=Vect.getNormal(v1, v2);
       
        double k=0.8;
        
        Vect v1n=new Vect(pn1.xr2,pn1.yr2,pn1.zr2);
        Vect v2n=new Vect(pn2.xr2,pn2.yr2,pn2.zr2);
        Vect v3n=new Vect(pn3.xr2,pn3.yr2,pn3.zr2);
        Vect v4n=new Vect(pn4.xr2,pn4.yr2,pn4.zr2);
        Vect v5n=new Vect(pn5.xr2,pn5.yr2,pn5.zr2);
        Vect v6n=new Vect(pn6.xr2,pn6.yr2,pn6.zr2);
        
        double visibleWall=Vect.getDotProduct(v1n, vo);
        double visibleWall2=Vect.getDotProduct(v2n, vo);
        double visibleWall3=Vect.getDotProduct(v3n, vo);
        double visibleWall4=Vect.getDotProduct(v4n, vo);
        double visibleWall5=Vect.getDotProduct(v5n, vo);
        double visibleWall6=Vect.getDotProduct(v6n, vo);
        
        Polygon wall=new Polygon();
        wall.addPoint(p1.x2d, p1.y2d);
        wall.addPoint(p2.x2d, p2.y2d);
        wall.addPoint(p4.x2d, p4.y2d);
        wall.addPoint(p3.x2d, p3.y2d);
        wall.translate(60,-20);
        
        //g.setColor(new Color(0,200,0));
        //g.fillPolygon(wall);
        
        g.setColor(new Color(0,150+(int)(k*8*visibleWall),0));
        if(visibleWall>0){g.fillPolygon(wall);}
        
        
               
        Polygon wall2=new Polygon();
        wall2.addPoint(p5.x2d, p5.y2d);
        wall2.addPoint(p6.x2d, p6.y2d);
        wall2.addPoint(p8.x2d, p8.y2d);
        wall2.addPoint(p7.x2d, p7.y2d);
        wall2.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall2),0));
        if(visibleWall2>0){g.fillPolygon(wall2);}
        
       
        Polygon wall3=new Polygon();
        wall3.addPoint(p1.x2d, p1.y2d);
        wall3.addPoint(p5.x2d, p5.y2d);
        wall3.addPoint(p6.x2d, p6.y2d);
        wall3.addPoint(p2.x2d, p2.y2d);
        wall3.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall3),0));
        if(visibleWall3>0){g.fillPolygon(wall3);}
        
        
        Polygon wall4=new Polygon();
        wall4.addPoint(p3.x2d, p3.y2d);
        wall4.addPoint(p7.x2d, p7.y2d);
        wall4.addPoint(p8.x2d, p8.y2d);
        wall4.addPoint(p4.x2d, p4.y2d);
        wall4.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall4),0));
        if(visibleWall4>0){g.fillPolygon(wall4);}
        
        Polygon wall5=new Polygon();
        wall5.addPoint(p2.x2d, p2.y2d);
        wall5.addPoint(p6.x2d, p6.y2d);
        wall5.addPoint(p8.x2d, p8.y2d);
        wall5.addPoint(p4.x2d, p4.y2d);
        wall5.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall5),0));
        if(visibleWall5>0){g.fillPolygon(wall5);}
        
        Polygon wall6=new Polygon();
        wall6.addPoint(p1.x2d, p1.y2d);
        wall6.addPoint(p5.x2d, p5.y2d);
        wall6.addPoint(p7.x2d, p7.y2d);
        wall6.addPoint(p3.x2d, p3.y2d);
        wall6.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall6),0));
        if(visibleWall6>0){g.fillPolygon(wall6);}
        
        //draw demo end
        }
        
        g.setColor(Color.black);
        
        
        for(Point3d p:vertices)
        {
            p.calculate2dpoint();
            g.drawLine(p.x2d,p.y2d, p.x2d,p.y2d);
        }
        
        
           
            
            
         
            
           
            
            /*
            if(set_center==false)
            {
            pcenter_1.moveVectorOriginal(30000,-3000,-40000);
            pcenter_2.moveVectorOriginal(30000,-3000,-40000);
            pcenter_3.moveVectorOriginal(30000,-3000,-40000);
            pcenter_4.moveVectorOriginal(30000,-3000,-40000);
            set_center=true;
            }
            
            pcenter_1.rotateAxisY(angle);
            pcenter_1.rotateAxisX(angle);
            pcenter_1.calculate2dpoint();
            
            pcenter_2.rotateAxisY(angle);
            pcenter_2.rotateAxisX(angle);
            pcenter_2.calculate2dpoint();
            
            pcenter_3.rotateAxisY(angle);
            pcenter_3.rotateAxisX(angle);
            pcenter_3.calculate2dpoint();
            
            pcenter_4.rotateAxisY(angle);
            pcenter_4.rotateAxisX(angle);
            pcenter_4.calculate2dpoint();
            
            pcenter_1.calculate2dpoint();
            pcenter_2.calculate2dpoint();
            pcenter_3.calculate2dpoint();
            pcenter_4.calculate2dpoint();
             
            g.drawLine(pcenter_1.x2d,pcenter_1.y2d, pcenter_2.x2d,pcenter_2.y2d);
            g.drawLine(pcenter_1.x2d,pcenter_1.y2d, pcenter_3.x2d,pcenter_3.y2d);
            g.drawLine(pcenter_1.x2d,pcenter_1.y2d, pcenter_4.x2d,pcenter_4.y2d);
            */
            g.setColor(Color.black);
            //punkt 0,0,0
            
        ArrayList<Triangle> triangles=new ArrayList<Triangle>();

        
        
        Triangle.total_trianles_number=0;
        
        if(doom==true){
            
            
            
            
            g.setColor(Color.red);
        
            Point3d pc1=vertices_xyz.get(0);
            Point3d pc2=vertices_xyz.get(1);
            Point3d pc3=vertices_xyz.get(2);
            Point3d pc4=vertices_xyz.get(3);
            
            //p.rotateAxisY(angle);
            //p.rotateAxisX(angle);
            pc1.calculate2dpoint();
            pc2.calculate2dpoint();
            pc3.calculate2dpoint();
            pc4.calculate2dpoint();
            g.drawLine(pc1.x2d,pc1.y2d, pc2.x2d,pc2.y2d);
            g.drawLine(pc1.x2d,pc1.y2d, pc3.x2d,pc3.y2d);
            g.drawLine(pc1.x2d,pc1.y2d, pc4.x2d,pc4.y2d);
        
            //punkt 0,0,0
            
                //doom
                int qf=4688;
                
                if(tr_map==false)
                { 
                    if(quake==true) 
                    {
                        qf=65006;
                        //cube_angleX=cube_angleX+5;
                        //cube_angleX=5;
                    }
                    
                    if(quake==false) qf=4688;
                    //if(quake==false) qf=111000;
                }
                
                
                if(tr_map==true) qf=3236;
                
                //for(int i=0;i<4688;i++)
                for(int i=0;i<qf;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                    
                   
                }
                  
            
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                float color_v=0;
                for(Triangle t:triangles)
                {
                    t.v1.calculate2dpoint();
                    t.v2.calculate2dpoint();
                    t.v3.calculate2dpoint();
                }
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    
                    Polygon poly2=new Polygon();
                   
                    quake_standard_shading=false;
                    if(quake_standard_shading==true) color_v=t.v1.zr2*0.01f;
                    
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                   
                    
                    int color=250;
                    color=250-(int)color_v;
                    //color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                    
                    if(tr_map==true){
                        t.minus=true;

                        if(calculate_normals==true){
                            t.m=100;
                            
                            float n=250-t.calculateNormal();
                            color=(int)(n);
                            if(color>255) color=255;
                            if(color<200) color=200;
                        }
                    }
                    
                    if(tr_map==false){
                        t.minus=true;
                        
                        color=250-(int)(color_v);
                        if(color>255) color=100;
                        if(color<100) color=100;
                            
                        if(calculate_normals==true){
                            float n=t.calculateNormal();
                            
                            color=200-(int)(n);
                            
                            
                            
                            if(color>255) color=100;
                            if(color<100) color=100;
                        }
                    }
                    
                    
                    g.setColor(new Color(color,color,color));
                    
                    if(quake==true){
                        color=(int)(color);
                        if(color>255) color=255;
                        if(color<0) color=0;
                        g.setColor(new Color(color,color,color));
                    }
                    //if(t.triangle_number>=triangle_pointer&&t.triangle_number<=triangle_pointer+200){g.setColor(new Color(255,0,0));}
                    
                     
                    int dd=-400;
                    //int dx=1000;
                    
                    if(t.v1.zr2>dd&&t.v2.zr2>dd&&t.v3.zr2>dd&&(t.v4==null||t.v4.zr2>dd)){
                    //if(t.v1.xr2>dd-dx&&t.v2.xr2>dd-dx&&t.v3.xr2>dd-dx&&(t.v4==null||t.v4.zr2>dd-dx)){
                    //if(t.v1.x2d>0&&t.v2.x2d>0&&t.v3.x2d>0&&t.v1.x2d<640&&t.v2.x2d<640&&t.v3.x2d<640){
                    //if(t.v1.y2d>0&&t.v2.y2d>0&&t.v3.y2d>0&&t.v1.y2d<480&&t.v2.y2d<480&&t.v3.y2d<480){
                    
                        
                        
                            if(wire_frame==false)
                            {
                            g.fillPolygon(poly);

                            //g.fillPolygon(poly2);
                            //g.fillPolygon(poly3);
                            //g.fillPolygon(poly4);
                            }
                    
                    
                            g.setColor(new Color(0,0,0));
                            
                            //if(t.triangle_number>=triangle_pointer&&t.triangle_number<=triangle_pointer+200){g.setColor(new Color(255,0,0));}
                            //System.out.println(""+(triangle_pointer+200));
                            
                            
                            g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                            g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);

                            if(t.v4==null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                            }

                            if(t.v4!=null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                            g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                            }
                    //}
                    //}
                   }
                    
                     
                }
        }
        
        //wyswietlanie dla lamborghini
        if(lamborghini==true){
            
                for(int i=0;i<14784;i++)
                
                //doom
                //for(int i=0;i<4796;i++)
                
                //q2dm1
                //for(int i=0;i<32796;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                   
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    Polygon poly2=new Polygon();
                   
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                     
                    int color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                    
                    
                    if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=255+(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<200) color=200;
                    }
                    
                    g.setColor(new Color(color,color,color));
                    
                    
                    int dd=0;
                    //if(t.v1.zr2>dd&&t.v2.zr2>dd&&t.v3.zr2>dd){
                    if(t.v1.x2d>0&&t.v2.x2d>0&&t.v3.x2d>0&&t.v1.x2d<640&&t.v2.x2d<640&&t.v3.x2d<640)
                    if(t.v1.y2d>0&&t.v2.y2d>0&&t.v3.y2d>0&&t.v1.y2d<480&&t.v2.y2d<480&&t.v3.y2d<480)
                    {
                    {    
                        
                            if(wire_frame==false)
                            {
                            g.fillPolygon(poly);

                            //g.fillPolygon(poly2);
                            //g.fillPolygon(poly3);
                            //g.fillPolygon(poly4);
                            }
                    
                    
                            g.setColor(new Color(0,0,0));
                            g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                            g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);

                            if(t.v4==null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                            }

                            if(t.v4!=null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                            g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                            }
                    }
                    }
                   //}
                    
                     
                }
        }
        
        
         if(tomb_raider==true){
                for(int i=0;i<21414;i++)
                {
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);

                    triangles.add(new Triangle(p1,p2,p3));
                     
                    Polygon poly=new Polygon();
                    poly.addPoint(p1.x2d,p1.y2d);
                    poly.addPoint(p2.x2d,p2.y2d);
                    poly.addPoint(p3.x2d,p3.y2d);
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    
                    
                    
                    
                    
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    //int color=255-(int)(0.01f*t.v1.zr2);
                    int color=250;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=250+(int)(n);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));
                   
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        
         
         if(crash_bandicoot==true){
             int q=0;
                for(int i=0;i<2196;i++)
                {
                   
                    q++;
                    
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    triangles.add(new Triangle(p1,p2,p3));
                    
                    
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    int color=255-(int)(0.01f*t.v1.zr2);
                    color=250;
                    if(color>=255) color=255;
                    if(color<=0) color=0;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=250+(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));

                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }

                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        //teapot
        if(tea_pot==true){
                for(int i=0;i<30000;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                   
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    Polygon poly2=new Polygon();
                   
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                     
                    int color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=200-(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));
                    
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    
                    //g.fillPolygon(poly2);
                    //g.fillPolygon(poly3);
                    //g.fillPolygon(poly4);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    
                    if(t.v4==null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                    }
                    
                    if(t.v4!=null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                    g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                    }
                     
                }
        }
         
        g.setColor(Color.black);
        g.setFont(new Font("System", Font.BOLD, 10));
        g.drawString("Mateusz Pawlowski. 3D Software Renderer. 2023.", 190, 450);
    }

    public void line(int x,int y,int x2,int y2)
    {
    g.drawLine(x+60, y-20,x2+60,y2-20);
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        R_3D rds=new R_3D();
        
        
        rds.panel=rds;
        
        rds.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        rds.thread=new Thread(rds);
        rds.thread.start();
        
        rds.frame.getContentPane().add(rds.panel);
        rds.frame.setLocation(500, 300);
        rds.frame.pack();
        rds.frame.show();
        
        rds.rotateDown();
        rds.rotateDown();
        rds.rotateDown();
        //rds.play();
        
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

   

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent mwe) {
       double whell_rotation=mwe.getPreciseWheelRotation();
       if(whell_rotation>0)
       {
           up();
           //triangle_pointer++;
       }
       
       if(whell_rotation<0)
       {
           down();
           //triangle_pointer--;
       }
    }
}
